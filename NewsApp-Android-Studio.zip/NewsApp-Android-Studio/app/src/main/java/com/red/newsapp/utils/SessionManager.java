package com.red.newsapp.utils;

public class SessionManager {
}
